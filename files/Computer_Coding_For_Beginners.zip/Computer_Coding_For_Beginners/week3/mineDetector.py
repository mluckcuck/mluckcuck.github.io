gridOfMines = [["O", "O", "M", "O", "M"],
        ["O", "M", "M", "O", "M"],
        ["O", "O", "M", "M", "O"],
        ["O", "M", "O", "O", "O"],
        ["O", "O", "O", "M", "M"]]

def printGrid(grid):
    pass

def mineDetector(grid):
    pass

printGrid(gridOfMines)
mineList = mineDetector(gridOfMines)
print(mineList)
