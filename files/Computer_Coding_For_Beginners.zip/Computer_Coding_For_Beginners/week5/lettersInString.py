""" Build a dictionary (letters) that maps each letter found in the string
to the number of times it occurs in the string
"""

letters = dict()

string = "the quick brown, fox jumps over the lazy dog"


print(letters)


