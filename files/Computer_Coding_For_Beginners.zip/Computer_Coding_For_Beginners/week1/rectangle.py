"""Draw a purple rectangle """

from turtle import *


length = 100
width = 60


penup()
setpos(0,0)
pendown()


