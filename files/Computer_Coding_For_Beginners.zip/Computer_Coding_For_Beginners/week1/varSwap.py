""" Swaps the variables x and y"""
x = 10
y = 20

print ("x = ", x, " y = ", y)

#############SWAP##########


############################
print ("x = ", x, " y = ", y)
