""" Quizzes the user on multiplication """
import random

num1 = random.randrange(1,10)
num2 = random.randrange(1,10)

print(num1)
print(num2)
