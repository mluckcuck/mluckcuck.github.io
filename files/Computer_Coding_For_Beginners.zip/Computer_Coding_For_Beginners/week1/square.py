"""Draw a blue square """

from turtle import *


length = 100
angle = 90 

penup()
setpos(0,0)
pendown()


