"""Totals the cost of tea being purchased """

teaCost = 0.50

howManyTeas = int(input("How Many Teas?"))

teaTotal = howManyTeas * teaCost

print( "Tea Total for " + str(howManyTeas) + " teas is £" + str(teaTotal))
